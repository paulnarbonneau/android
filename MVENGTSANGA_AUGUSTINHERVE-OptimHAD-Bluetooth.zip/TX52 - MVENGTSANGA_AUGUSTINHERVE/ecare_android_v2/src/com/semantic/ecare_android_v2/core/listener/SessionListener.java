package com.semantic.ecare_android_v2.core.listener;


public interface SessionListener {
	public void disconnect();
}
