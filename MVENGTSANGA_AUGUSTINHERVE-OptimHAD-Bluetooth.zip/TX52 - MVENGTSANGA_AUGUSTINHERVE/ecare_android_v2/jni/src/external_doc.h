/**
 * \file external_doc.h
 * \brief Documentation to automatic generated files.
 *
 *  \date Sep 8, 2010
 *  \author Adrian Guedes
 */

/**
 * \file serv_dbus_api_device.h
 * \brief Device DBus API.
 */

/**
 * \file serv_dbus_api.h
 * \brief Server DBus API.
 */
