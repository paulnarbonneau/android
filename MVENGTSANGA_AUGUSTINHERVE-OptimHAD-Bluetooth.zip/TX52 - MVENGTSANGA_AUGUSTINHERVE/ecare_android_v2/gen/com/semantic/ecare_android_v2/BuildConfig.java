/** Automatically generated file. DO NOT MODIFY */
package com.semantic.ecare_android_v2;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}